import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { DbApiService } from 'src/app/services/db-api.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  usuario: string = '';
  contrasena: string = '';
  dataUsuario: string = '';
  dataContrasena: string = '';
  banderinVerificar: number = 0;
  
  constructor(public alertController: AlertController, private dbApi: DbApiService, private router : Router) { }

  ngOnInit() {
    this.dbApi.obtenerCantidadUsuario().then(data => {
      if(data === 1){
        this.router.navigate(['menu']);
      }
    })
  }



// CREAR USUARIO  
  crearUsuario(){
    this.presentFormularioCrearUsuario();
  }
 // se crea el usuario con este formulario
  async presentFormularioCrearUsuario() {
    const alert = await this.alertController.create({
      header: 'Nuevo Usuario',
      inputs: [
        {
          name: 'txt_usuario',
          type: 'text',
          placeholder: 'Usuario'
        },
        {
          name: 'txt_contrasena',
          type: 'password',
          placeholder: 'Contraseña'
        },
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: (data) => {
              this.dbApi.eliminarUser();
              this.almacenarUsuariobd(data.txt_usuario, data.txt_contrasena)

              if(this.banderinVerificar === 1){ // si el almacenarUsuariobd retorna un 1 tambien se guarda el usuario en la api
                this.dbApi.crearUsuario(data.txt_usuario, data.txt_contrasena).subscribe(data => {
                  console.log(data);
                  console.log('usuario creado ok');
                  this.presentAlert();
                }); 
              }else{
                console.log('hcr: usuario no creado login.ts')
              }

            
              console.log(data);
              
          }
        }
      ]
    });

    await alert.present();
  }
  // mensaje para mostrar que el usuario se almaceno correctamente
  async presentAlert() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Alert',
      message: 'Usuario almacenado correctamente',
      buttons: ['OK']
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    console.log('onDidDismiss resolved with role', role);
  }
  // mensaje para mostrar que la contraseña se modifico correctamente
  async presentAlertConfirmarContrasena() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Confirmacion Aceptada',
      message: 'Contraseña se ha cambiado correctamente',
      buttons: ['OK']
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    console.log('onDidDismiss resolved with role', role);
  }




// MODIFICAR CONTRASEÑA   
  recuperarClave(){
    this.presentFormularioModificarContrasena();
  }

  async presentFormularioModificarContrasena() {
    const alert = await this.alertController.create({
      header: 'Modificar Contrasena',
      inputs: [
        {
          name: 'txt_usuario',
          type: 'text',
          placeholder: 'Usuario'
        },
        {
          name: 'txt_contrasena',
          type: 'password',
          placeholder: 'Contraseña'
        },
        {
          name: 'txt_contrasenaNueva',
          type: 'password',
          placeholder: 'Nueva Contraseña'
        },
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: (data) => {
            this.dataUsuario = data.txt_usuario;
            this.dataContrasena = data.txt_contrasenaNueva;

            this.dbApi.validarUsuario(data.txt_usuario, data.txt_contrasena).subscribe(data => {
              console.log(data);
              if (data.result === 'LOGIN OK' ) // si el login funciona llama a la funcion para modificar la contraseña con la api
              {
                this.dbApi.modificarContrasena(this.dataUsuario, this.dataContrasena).subscribe(data => {
                  console.log(data);
                  console.log('hcr: Contraseña Modificada');
                  this.presentAlertConfirmarContrasena();
                });
                
              }
              else // si el usuario no existe mandara este mensaje
              {
                console.log('hcr: ' + data.result)
                console.log('hcr:USUARIO NO VALIDADO');
                this.presentAlertDatosInvalidos();
              }
              
            });
          }
        }
      ]
    });

    await alert.present();
  }

  
 // mensaje para mostrar que los datos ingresados no son validos
  async presentAlertDatosInvalidos() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      header: 'Error',
      message: 'Los datos ingresados no son correctos.',
      buttons: ['OK']
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
    console.log('onDidDismiss resolved with role', role);
  }

 // si el validar usuario retorna un true lo redirige a la pagina del menu 
  validarUsuario(){
    this.dbApi.validarUsuario(this.usuario, this.contrasena).subscribe(data => {
      if(data['result'] === 'LOGIN NOK') {
        this.dbApi.eliminarUser();
        console.log('hcr: login no ok ')
      }else{
        this.dbApi.eliminarUser();
        this.dbApi.almacenarUsuariobd(this.usuario, this.contrasena);
        this.router.navigate(['menu']);
      }
    })
  }
  // almacenar usuario en la bd y api
  almacenarUsuariobd(usuario, contrasena){
    this.dbApi.validarUsuariobd(usuario).then((data) => {
      if(!data){ // si el data retorna un false significa que el usuario no existe en la bd y api
        this.banderinVerificar = 1 // el banderin cambia a uno y se guarda el usuario en la bd
        this.dbApi.almacenarUsuariobd(usuario, contrasena);
        //this.dbApi.crearUsuario(this.dataUsuario, this.dataContrasena);
        this.presentAlert();
        //console.log('hcr:' + this.dataUsuario + this.dataContrasena)
      }else {
        console.log('hcr: usuario ya existe en la bd')
        this.banderinVerificar = 0
      }
    })
  }


}

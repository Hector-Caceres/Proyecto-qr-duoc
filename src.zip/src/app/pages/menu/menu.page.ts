import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { DbApiService } from 'src/app/services/db-api.service';
import { NavigationExtras, Router } from '@angular/router';
import { Camera, CameraResultType } from '@capacitor/camera';
import { BarcodeScanner } from '@ionic-native/barcode-scanner/ngx';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.page.html',
  styleUrls: ['./menu.page.scss'],
})
export class MenuPage implements OnInit {

  nombreUsuario: string = '';
  ruta: string = '';
  texto: string = '';

  constructor(public alertController: AlertController, private dbApi: DbApiService, private router: Router, private qr: BarcodeScanner) { }

  ngOnInit() {
    this.dbApi.obtenerNombreUsuario().then(data => {
      this.nombreUsuario = data
    })
  }

  recuperarClave(){
    this.presentFormularioModificarContrasena();
  }

  async presentFormularioModificarContrasena() {
    const alert = await this.alertController.create({
      header: 'Modificar Contrasena',
      inputs: [
        {
          name: 'txt_usuario',
          type: 'text',
          placeholder: 'Usuario'
        },
        {
          name: 'txt_contrasena',
          type: 'password',
          placeholder: 'Contraseña'
        },
        {
          name: 'txt_nuevaContrasena',
          type: 'password',
          placeholder: 'Nueva Contraseña'
        },
      ],
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: (data) => {

            this.dbApi.modificarContrasena(data.txt_usuario, data.txt_nuevaContrasena).subscribe(data => {
              console.log(data);
              console.log('contraseña modificada');
              //this.presentAlert();
            });
          }
        }
      ]
    });

    await alert.present();
  }

  cerrarSesion(){
    this.dbApi.eliminarUser();
    this.router.navigate(['login'], {replaceUrl: true});

  }

  leerQR(){
    this.qr.scan().then(info => {
      this.texto = info['text']
    })
  }
}

import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Router } from '@angular/router';
import { HttpClient, HttpHeaders, HttpClientModule } from '@angular/common/http';
import { Respuesta } from '../interfaces/usuario-respuesta';
import {UsuarioInterface} from '../interfaces/usuario-interface';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite/ngx';

@Injectable({
  providedIn: 'root'
})
export class DbApiService {

  rutaBase = 'https://fer-sepulveda.cl/api/api-prueba2.php';
  
  banderin : Number;
  constructor(private router: Router, private http: HttpClient, private sqlite: SQLite) {
    this.sqlite.create({ // se crea la bd y su tabla 
      name: 'usuarios.db',
      location: 'default'
    }).then((db: SQLiteObject)=> {
      db.executeSql('CREATE TABLE IF NOT EXISTS USUARIO (USUARIO VARCHAR(75), CONTRASENA VARCHAR(30))', []).then(() => {
        console.log('hcr: tabla creada ok');
      }).catch(e => {
        console.log('hcr: tabla no ok')
      })
    }).catch(e  => {
      console.log('hcr: base de datos nok')
    })
   }
  // se crea el usuario en la api 
  crearUsuario(usuario, contrasena){
    return this.http.post(this.rutaBase, {nombreFuncion: 'UsuarioAlmacenar', parametros: [usuario, contrasena]});
  }

  // modificar contraseña en la api
  modificarContrasena(usuario, contrasena) {
    return this.http.put(this.rutaBase, { nombreFuncion: "UsuarioModificarContrasena", parametros: { usuario: usuario, contrasena: contrasena } });
  }
  // validar si el usuario existe en la api
  validarUsuario(usuario, contrasena) {
    return this.http.get<Respuesta>(this.rutaBase + '?nombreFuncion=UsuarioLogin&usuario=' + usuario + "&contrasena=" + contrasena);
  }



// se valida el login con la api si retorna un login ok el banderin queda en un 1 y si queda en un 1 retorna un true


// almacenar usuario en la bd 
almacenarUsuariobd(usuario ,contrasena){
  this.sqlite.create({
    name: 'usuarios.db',
    location: 'default'
  }).then((db: SQLiteObject)=> {
    db.executeSql('INSERT INTO USUARIO VALUES(?, ?) ', [usuario, contrasena]).then(() => {
      //this.http.post(this.rutaBase, {nombreFuncion: 'UsuarioAlmacenar', parametros: [usuario, contrasena]});
      console.log('hcr: usuario creado ok');
    }).catch(e => {
      console.log('hcr: usuario no ok')
    })
  }).catch(e  => {
    console.log('hcr: base de datos nok')
  })
 }
 // se valida si existe el usuario en la bd con un count si entrega un 1 existe entonces retornara un true
 validarUsuariobd(usuario){
  return this.sqlite.create({
    name: 'usuarios.db',
    location: 'default'
  }).then((db: SQLiteObject)=> {
    return db.executeSql('SELECT COUNT(USUARIO) AS CANTIDAD FROM USUARIO WHERE USUARIO = ? ', [usuario]).then((data) => {

      if(data.rows.item(0).CANTIDAD === 0){
        return false; // false : usuario no existe en la bd 
        console.log('hcr: usuario no existe se puede crear');
      }

      return true;
      
    }).catch(e => {
      console.log('hcr: usuario si existe en la bd')
      return true;
    })
  }).catch(e  => {
    console.log('hcr: base de datos nok')
    return true;
  })
 }
 // se modifica la contrasena en la bd 
 modificarContrasenabd(usuario, nuevaContrasena){
  this.sqlite.create({
    name: 'usuarios.db',
    location: 'default'
  }).then((db: SQLiteObject)=> {
    db.executeSql("UPDATE USUARIO SET CONTRASENA = '" + nuevaContrasena + "' WHERE USUARIO =  '" + usuario + "'", []).then((data) => {
      console.log('hcr: usuario modificado');
      
    }).catch(e => {
      console.log('hcr: usuario no modificado')
      
    })
  }).catch(e  => {
    console.log('hcr: base de datos nok')
    
  })
 }

 // eliminar usuario de la bd
 eliminarUser(){
  this.sqlite.create({
    name: 'usuarios.db',
    location: 'default'
  }).then((db: SQLiteObject)=> {
    db.executeSql("DELETE FROM USUARIO", []).then((data) => {
      console.log('hcr: usuario eliminado');
      
    }).catch(e => {
      console.log('hcr: usuario no eliminado')
      
    })
  }).catch(e  => {
    console.log('hcr: base de datos nok')
    
  })
 }

 obtenerCantidadUsuario(){
  return this.sqlite.create({
    name: 'usuarios.db',
    location: 'default'
  }).then((db: SQLiteObject)=> {
    return db.executeSql('SELECT COUNT(USUARIO) AS CANTIDAD FROM USUARIO', []).then((data) => {

      return data.rows.item(0).CANTIDAD
    }).catch(e => {
      console.log('hcr: error al obtener cantidad de usuario')
      return 99;
    })
  }).catch(e  => {
    console.log('hcr: base de datos nok')
    return 99;

  })
 }

 obtenerNombreUsuario(){
  return this.sqlite.create({
    name: 'usuarios.db',
    location: 'default'
  }).then((db: SQLiteObject)=> {
    return db.executeSql('SELECT USUARIO FROM USUARIO', []).then((data) => {

      return data.rows.item(0).USUARIO
    }).catch(e => {
      console.log('hcr: error al obtener cantidad de usuario')
      return '';
    })
  }).catch(e  => {
    console.log('hcr: base de datos nok')
    return '';

  })
 }

 canActivate(){
   this.obtenerCantidadUsuario().then(data => {
     if(data === 1){
       return true;
     }else{
       this.router.navigate(['login']);
       return false;
     }
   })
   return true;
 }
 }








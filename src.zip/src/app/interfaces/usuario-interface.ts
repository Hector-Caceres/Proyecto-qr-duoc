export interface UsuarioInterface {
}

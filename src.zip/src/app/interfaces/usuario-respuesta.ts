export interface Respuesta {
    result?: string;
}